class TSpaces {

  static const double spaceBtwItems = 14.0;
  static const double spaceBtwSections = 24.0;
  static const double spaceBtwTextFormFields = 18.0;
  static const double defaultSpace = 20.0;
}
